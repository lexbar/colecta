<?php

namespace Colecta\ColectiveBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ColectaColectiveBundle extends Bundle
{
}
