<?php

namespace Colecta\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ColectaUserBundle extends Bundle
{
}
