<?php

namespace Colecta\UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Security\Core\SecurityContext;


class MessageController extends Controller
{
    
    public function indexAction()
    {
        
    }
}
