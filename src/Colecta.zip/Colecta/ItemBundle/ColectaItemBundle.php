<?php

namespace Colecta\ItemBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ColectaItemBundle extends Bundle
{
}
