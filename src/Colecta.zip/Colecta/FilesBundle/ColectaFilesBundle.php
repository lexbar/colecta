<?php

namespace Colecta\FilesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ColectaFilesBundle extends Bundle
{
}
