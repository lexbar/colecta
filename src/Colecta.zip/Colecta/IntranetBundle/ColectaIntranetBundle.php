<?php

namespace Colecta\IntranetBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ColectaIntranetBundle extends Bundle
{
}
