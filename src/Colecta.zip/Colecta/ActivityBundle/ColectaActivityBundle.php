<?php

namespace Colecta\ActivityBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ColectaActivityBundle extends Bundle
{
}
